package com.sjsu.cmpe.bean;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

public class BMWBean {

	private String model;
	private String colour;
	private List<String> features;

	public BMWBean(JSONObject json) {
		try {
			this.model = json.getString("model");
		this.colour = json.getString("color");
		List<String> sample = new ArrayList();
		sample.add(json.getString("feature1"));
		sample.add(json.getString("feature2"));
		sample.add(json.getString("feature3"));
		this.features = sample;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public BMWBean()
	{	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public List<String> getFeatures() {
		return features;
	}

	public void setFeatures(List<String> features) {
		this.features = features;
	}
}
