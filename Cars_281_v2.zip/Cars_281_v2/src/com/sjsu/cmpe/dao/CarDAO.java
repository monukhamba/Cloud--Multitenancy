package com.sjsu.cmpe.dao;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoURI;


public class CarDAO extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String ACCESS_TOKEN = "ACCESS_TOKEN";
	private static final String INSTANCE_URL = "INSTANCE_URL";

	private void showCars(String instanceUrl, String accessToken,
			PrintWriter writer) throws ServletException, IOException {
		
		System.out.println("Inside ShowAccounts*********");
		HttpClient httpclient = new HttpClient();
		GetMethod get = new GetMethod(instanceUrl
				+ "/services/data/v20.0/query");

		// set the token in the header
		get.setRequestHeader("Authorization", "OAuth " + accessToken);

		// set the SOQL as a query param
		NameValuePair[] params = new NameValuePair[1];

		params[0] = new NameValuePair("q",
				//"SELECT Color__c, Model__c from Team02_All_Cars__c LIMIT 100");
				"SELECT Customer_Name__c, Cust_Bank_Acc_No__c, Customer_Id__c from Team02_Cust_Details__c where Tenant_Id__c='2'");
		get.setQueryString(params);

		try {
			httpclient.executeMethod(get);
			if (get.getStatusCode() == HttpStatus.SC_OK) {
				// Now lets use the standard java json classes to work with the
				// results
				try {
					JSONObject response = new JSONObject(
							new JSONTokener(new InputStreamReader(
									get.getResponseBodyAsStream())));
					System.out.println("Query response: "+ response.toString(2));

					writer.write(response.getString("totalSize")
							+ " record(s) returned\n\n");

					JSONArray results = response.getJSONArray("records");

					for (int i = 0; i < results.length(); i++) {
						writer.write(results.getJSONObject(i).getString("Cust_Bank_Acc_No__c")
								+ ", "
								+ results.getJSONObject(i).getString("Customer_Id__c")
								+ ","+
								results.getJSONObject(i).getString("Customer_Name__c")+"\n");
					}
					writer.write("\n");
				} catch (JSONException e) {
					e.printStackTrace();
					throw new ServletException(e);
				}
			}else{
				writer.write("Inside Else ShowCar madhe Matter zala ahe HttpStatus cha");	
			}
		} finally {
			get.releaseConnection();
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		doGet(request, response);
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		PrintWriter writer = response.getWriter();

		String accessToken = (String) request.getSession().getAttribute(ACCESS_TOKEN);

		String instanceUrl = (String) request.getSession().getAttribute(INSTANCE_URL);

		if (accessToken == null) {
			writer.write("Error - no access token");
			return;
		}

		writer.write("We have an access token: " + accessToken + "\n" + "Using instance " + instanceUrl + "\n\n");

		showCars(instanceUrl, accessToken, writer);
		if(request.getSession()!=null){
			if(request.getSession().getAttribute("Company")!=null){
				createCustRecord(request, instanceUrl, accessToken, writer);
				createOrderRecord(request, instanceUrl, accessToken, writer);
				writeDataToMongo(request, response, writer);
			}
		}else{
			writer.write("Session is null");
		}
		
		//response.sendRedirect(request.getContextPath() + "/Mongoconnector");
	}

	/**
	 * This method will create a New  Record in Team02_Cust_Details__c Custom Object
	 * in SaleForce
	 * @param request
	 * @param instanceUrl
	 * @param accessToken
	 * @param writer
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	private String createCustRecord(HttpServletRequest request, String instanceUrl,
			String accessToken, PrintWriter writer) throws ServletException, IOException {
		String custId = null;
		
		JSONObject custDetail = new JSONObject();

		try {
			custDetail.put("Tenant_Id__c", request.getSession().getAttribute("Tenant_Id__c"));
			custDetail.put("Customer_Name__c", request.getSession().getAttribute("Customer_Name__c"));
			custDetail.put("Customer_Address__c", request.getSession().getAttribute("Customer_Address__c"));
			custDetail.put("Customer_Ph_Number__c", request.getSession().getAttribute("Customer_Ph_Number__c"));
			custDetail.put("Customer_Email__c", request.getSession().getAttribute("Customer_Email__c"));
			if(request.getSession().getAttribute("Cust_Credit_Debit_Number__c")!=null){
				custDetail.put("Cust_Credit_Debit_Number__c", request.getSession().getAttribute("Cust_Credit_Debit_Number__c"));
			}
			custDetail.put("Cust_Bank_Acc_No__c", request.getSession().getAttribute("Cust_Bank_Acc_No__c"));
		} catch (JSONException e) {
			e.printStackTrace();
			throw new ServletException(e);
		}

		HttpClient httpclient = new HttpClient();

		PostMethod post = new PostMethod(instanceUrl + "/services/data/v26.0/sobjects/Team02_Cust_Details__c/");

		post.setRequestHeader("Authorization", "OAuth " + accessToken);
		post.setRequestEntity(new StringRequestEntity(custDetail.toString(), "application/json", null));
		writer.write("\n\n\n Recieved JSON()==>" + custDetail.toString());

		try {
			//writer.write("\n Audimethod post.getURI().getURI()----------------------"+post.getURI().getURI());
			httpclient.executeMethod(post);
			writer.write("\n\n----------------------");
			writer.write("\npost.getStatusCode() value is==>" + post.getStatusCode() + " creating account\n\n");
			
			//writer.write("-----HttpStatus.SC_CREATED Value is " + HttpStatus.SC_CREATED);

			if (post.getStatusCode() == HttpStatus.SC_CREATED) {
				try {
					writer.write(" HttpStatus.SC_CREATED\n\n");
					JSONObject response = new JSONObject(new JSONTokener(new InputStreamReader(post.getResponseBodyAsStream())));
					System.out.println("Create response: "+ response.toString(2));

					if (response.getBoolean("success")) {
						custId = response.getString("id");
						writer.write("New record id " + custId + "\n\n");
						//readNewRecord(custId, request, instanceUrl, accessToken, writer);
					}
				} catch (JSONException e) {
					e.printStackTrace();
					//throw new ServletException(e);
				}
			}else{
				writer.write("Cannot get HttpStatus Code ");
			}
		} finally {
			post.releaseConnection();
		}

		return custId;
	}
	
	/**
	 * 
	 * @param request
	 * @param instanceUrl
	 * @param accessToken
	 * @param writer
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	private String createOrderRecord(HttpServletRequest request, String instanceUrl,
			String accessToken, PrintWriter writer) throws ServletException, IOException {
		String orderId = null;
		
		JSONObject orderDetail = new JSONObject();

		try {
			orderDetail.put("Tenant_Id__c", request.getSession().getAttribute("Tenant_Id__c"));
			orderDetail.put("Customer_Id__c", request.getSession().getAttribute("Customer_Id__c"));
			orderDetail.put("Model__c", request.getSession().getAttribute("Model__c"));
			orderDetail.put("Color__c", request.getSession().getAttribute("Color__c"));
			orderDetail.put("Feature_001__c", request.getSession().getAttribute("Feature_001__c"));
			orderDetail.put("Feature_002__c", request.getSession().getAttribute("Feature_002__c"));
			orderDetail.put("Feature_003__c", request.getSession().getAttribute("Feature_003__c"));
			orderDetail.put("Feature_004__c", request.getSession().getAttribute("Feature_004__c"));
			orderDetail.put("Feature_005__c", request.getSession().getAttribute("Feature_005__c"));
			orderDetail.put("Promo_Code__c", request.getSession().getAttribute("Promo_Code__c"));
		} catch (JSONException e) {
			e.printStackTrace();
			throw new ServletException(e);
		}

		HttpClient httpclient = new HttpClient();

		PostMethod post = new PostMethod(instanceUrl + "/services/data/v26.0/sobjects/Team02_Order_Details__c/");

		post.setRequestHeader("Authorization", "OAuth " + accessToken);
		post.setRequestEntity(new StringRequestEntity(orderDetail.toString(), "application/json", null));
		writer.write("\n\n\n Recieved JSON()==>" + orderDetail.toString());

		try {
			//writer.write("\n Audimethod post.getURI().getURI()----------------------"+post.getURI().getURI());
			httpclient.executeMethod(post);
			writer.write("\n\n----------------------");
			writer.write("\npost.getStatusCode() value is==>" + post.getStatusCode() + " creating account\n\n");
			
			//writer.write("-----HttpStatus.SC_CREATED Value is " + HttpStatus.SC_CREATED);

			if (post.getStatusCode() == HttpStatus.SC_CREATED) {
				try {
					writer.write(" HttpStatus.SC_CREATED\n\n");
					JSONObject response = new JSONObject(new JSONTokener(new InputStreamReader(post.getResponseBodyAsStream())));
					System.out.println("Create response: "+ response.toString(2));

					if (response.getBoolean("success")) {
						orderId = response.getString("id");
						writer.write("New record id " + orderId + "\n\n");
					}
				} catch (JSONException e) {
					e.printStackTrace();
					//throw new ServletException(e);
				}
			}else{
				writer.write("Cannot get HttpStatus Code ");
			}
		} finally {
			post.releaseConnection();
		}

		return orderId;
	}

	private void readNewRecord(String custId, HttpServletRequest request, String instanceUrl, String accessToken, PrintWriter writer) throws ServletException{
		HttpClient httpclient = new HttpClient();

		GetMethod get = new GetMethod(instanceUrl + "/services/data/v20.0/sobjects/Team02_Cust_Details__c/" + custId);

		// set the token in the header

		get.setRequestHeader("Authorization", "OAuth " + accessToken);

		try {
			httpclient.executeMethod(get);
			if (get.getStatusCode() == HttpStatus.SC_OK) {
				// Now lets use the standard java json classes to work with the
				// results
				try {
					JSONObject response = new JSONObject(
							new JSONTokener(new InputStreamReader(
									get.getResponseBodyAsStream())));
					System.out.println("Query response: "+ response.toString(2));

					/*writer.write(response.getString("totalSize")
							+ " record(s) returned\n\n");*/

					JSONArray results = response.getJSONArray("records");

					for (int i = 0; i < results.length(); i++) {
						writer.write("Newly creatred record details----"
								+ ", "
								+ results.getJSONObject(i).getString("Customer_Id__c")
								+ ","+
								results.getJSONObject(i).getString("Customer_Name__c")+"\n");
					}
					writer.write("\n");
				} catch (JSONException e) {
					e.printStackTrace();
					throw new ServletException(e);
				}
			}else{
				writer.write("Inside Else ShowCar madhe Matter zala ahe HttpStatus cha");	
			}
		} catch (HttpException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			get.releaseConnection();
		}
	}
	
	public void writeDataToMongo(HttpServletRequest request, HttpServletResponse response, 
			PrintWriter writer) throws IOException{
		MongoURI mongoURI = new MongoURI(System.getenv("MONGOHQ_URL"));
		DB db = mongoURI.connectDB();
		db.authenticate(mongoURI.getUsername(), mongoURI.getPassword());
		DBCollection collection = db.getCollection("details");
		 
		
		BasicDBObject doc = new BasicDBObject();
		doc.put("Tenant_Id__c", request.getSession().getAttribute("Tenant_Id__c"));
		doc.put("Customer_Name__c", request.getSession().getAttribute("Customer_Name__c"));
		doc.put("Customer_Address__c", request.getSession().getAttribute("Customer_Address__c"));
		
		collection.insert(doc);
		
		if(request.getSession().getAttribute("Company")!=null && 
				"Audi".equals(request.getSession().getAttribute("Company"))){
			response.sendRedirect("Audi_Congrats.html");
		}else if(request.getSession().getAttribute("Company")!=null && 
				"BMW_payment".equals(request.getSession().getAttribute("Company"))){
			response.sendRedirect("BMW_Thankyou.html");
		}
	}
}