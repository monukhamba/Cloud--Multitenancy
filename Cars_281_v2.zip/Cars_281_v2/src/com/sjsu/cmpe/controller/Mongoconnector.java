package com.sjsu.cmpe.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.BSONObject;
import org.bson.BasicBSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBAddress;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoURI;
import com.mongodb.util.JSON;
import com.sun.org.apache.xerces.internal.util.URI;

/**
 * Servlet implementation class mongoconnector
 */
public class Mongoconnector extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Mongoconnector() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		writer.write("Inside dopost MongoConnector");
		
		MongoURI mongoURI = new MongoURI(System.getenv("MONGOHQ_URL"));
		writer.write("Line 1");
		DB db = mongoURI.connectDB();
		writer.write("Line 2");
		db.authenticate(mongoURI.getUsername(), mongoURI.getPassword());
		writer.write("Line 3");
	//	Mongo mongo = new Mongo("widmore.mongohq.com",10010);
	//	DB db = mongo.getDB("projectcars");
		DBCollection collection = db.getCollection("details");
		writer.write("Line 4");
		 
		
		BasicDBObject doc = new BasicDBObject();
		writer.write("Line 5 creating BSOn");
		/*doc.put("Customer_Id", request.getParameter("Customer_Id"));
		doc.put("Feature_001", request.getParameter("Feature_001"));
		doc.put("Feature_002", request.getParameter("Feature_002"));
		doc.put("Feature_003", request.getParameter("Feature_003"));
		doc.put("Feature_004", request.getParameter("Feature_004"));
		doc.put("Feature_005", request.getParameter("Feature_005"));
		doc.put("Model", request.getParameter("Model"));
		doc.put("Tentant_Id", request.getParameter("Tentant_Id"));
		doc.put("Total_Price", request.getParameter("Total_Price"));*/
		/*doc.put("Tenant_Id__c", request.getSession().getAttribute("Tenant_Id__c"));
		doc.put("Customer_Name__c", request.getSession().getAttribute("Customer_Name__c"));
		doc.put("Customer_Address__c", request.getSession().getAttribute("Customer_Address__c"));*/
		
		doc.put("Tenant_Id__c", request.getSession().getAttribute("Tenant_Id__c"));
		doc.put("Customer_Name__c", request.getSession().getAttribute("Customer_Name__c"));
		doc.put("Customer_Address__c", request.getSession().getAttribute("Customer_Address__c"));
		
		writer.write("Let's test------");
		writer.write("request.getSession().getAttribute()===>"+request.getSession().getAttribute("Customer_Name__c"));
	/*	PrintWriter wrtr = response.getWriter();
		wrtr.write(request.getParameter("fname"));
		wrtr.write(request.getParameter("lname"));
		wrtr.write(request.getParameter("accno"));
		wrtr.write(request.getParameter("zip"));
		collection.insert(doc);*/
	//try{
			
		//	doc.put("Tenant_Id__c", request.getSession().getAttribute("Tenant_Id__c"));
			/*doc.put("fname", request.getParameter("fname"));
			doc.put("lname", request.getParameter("lname"));
			doc.put("accno", request.getParameter("accno"));
			doc.put("zip", request.getParameter("zip"));*/
			//doc.append("Cust_Credit_Debit_Number__c", request.getSession().getAttribute("Cust_Credit_Debit_Number__c"));
			//doc.append("Cust_Bank_Acc_No__c", request.getSession().getAttribute("Cust_Bank_Acc_No__c"));
			
			
			//}
		collection.insert(doc);
		writer.write("Collection inserted");
	/*	catch (Exception e) {
			e.printStackTrace();
			throw new ServletException(e);
		}
		*/
		if(request.getSession().getAttribute("Company")!=null && 
				"Audi".equals(request.getSession().getAttribute("Company"))){
			writer.write("Redirecting to thanks");
			response.sendRedirect("Audi_Congrats.html");
			
		}
	}
}
