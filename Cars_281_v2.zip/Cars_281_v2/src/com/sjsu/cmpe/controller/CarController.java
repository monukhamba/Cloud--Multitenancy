package com.sjsu.cmpe.controller;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class CarController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String ACCESS_TOKEN = "ACCESS_TOKEN";

	private static final String INSTANCE_URL = "INSTANCE_URL";

	private String clientId = null;

	private String clientSecret = null;

	private String redirectUri = null;

	private String environment = null;

	private String authUrl = null;

	private String tokenUrl = null;

	public void init() throws ServletException {
		clientId = this.getInitParameter("clientId");
		clientSecret = this.getInitParameter("clientSecret");
		redirectUri = this.getInitParameter("redirectUri");
		environment = this.getInitParameter("environment");

		try {
			authUrl = environment
					+ "/services/oauth2/authorize?response_type=code&client_id="
					+ clientId + "&redirect_uri="
					+ URLEncoder.encode(redirectUri, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new ServletException(e);
		}

		tokenUrl = environment + "/services/oauth2/token";
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String accessToken = (String) request.getSession().getAttribute(
				ACCESS_TOKEN);

		if (accessToken == null) {
			String instanceUrl = null;

			if (request.getRequestURI().endsWith("carController") && (request.getParameter("Company") != null)) {
				//set the retrieved company attribute to session
				request.getSession().setAttribute("Company", request.getParameter("Company"));
				//add the retrieved attribute to session  
				saveOrder(request, response);
				// we need to send the user to authorize
				if(request.getParameter("Company").equalsIgnoreCase("BMW")){
					//add the user selected features to session 
					request.getSession().setAttribute("Color__c",request.getParameter("color"));
					request.getSession().setAttribute("Model__c",request.getParameter("radio"));
					request.getSession().setAttribute("Feature_001__c",request.getParameter("feature1"));
					request.getSession().setAttribute("Feature_002__c",request.getParameter("feature2"));
					request.getSession().setAttribute("Feature_003__c",request.getParameter("feature3"));
					//redirect the user to payment page
					response.sendRedirect("BMW_payment.html");
				}/*else if(request.getParameter("Company").equalsIgnoreCase("BMW_payment")){
					response.sendRedirect(authUrl);
				}*/else if(request.getParameter("Company").equalsIgnoreCase("audiBuild")){
					request.getSession().setAttribute("Feature_001__c",request.getParameter("trim"));
					request.getSession().setAttribute("Feature_002__c",request.getParameter("gears"));
					//redirect the user to payment page
					response.sendRedirect("Audi_Buy.html");
				}else if(request.getParameter("Company").equalsIgnoreCase("audiModel")){
					request.getSession().setAttribute("Model__c",request.getParameter("model"));
					//redirect to build the car page
					response.sendRedirect("Audi_Build.html");
				}else if(request.getParameter("Company").equalsIgnoreCase("dodgeModel")){
					request.getSession().setAttribute("Model__c",request.getParameter("model"));
					request.getSession().setAttribute("Feature_001__c",request.getParameter("feature1"));
					request.getSession().setAttribute("Feature_002__c",request.getParameter("feature2"));
					//redirect the user to payment page
					response.sendRedirect("Dodge_Payment.html");
				}else if ((request.getParameter("Company")).equalsIgnoreCase("Cadillac_Home")) {
					request.getSession().setAttribute("Tenant_Id__c", "4");
					request.getSession().setAttribute("Model__c", "model");
					request.getSession().setAttribute("Color__c", "color");
					response.sendRedirect("CD_Cart.html");
				} else if ((request.getParameter("Company")).equalsIgnoreCase("MB_Model")) {
					request.getSession().setAttribute("Tenant_Id__c", "5");
					request.getSession().setAttribute("Color__c", "color");
					request.getSession().setAttribute("Model__c", "model");
					response.sendRedirect("MB_Customer_info.html");
				} else{
					response.sendRedirect(authUrl);	
				}
				return;
			} else {
				// System.out.println("Auth successful - got callback");
				String code = request.getParameter("code");

				HttpClient httpclient = new HttpClient();

				PostMethod post = new PostMethod(tokenUrl);
				post.addParameter("code", code);
				post.addParameter("grant_type", "authorization_code");
				post.addParameter("client_id", clientId);
				post.addParameter("client_secret", clientSecret);
				post.addParameter("redirect_uri", redirectUri);

				try {
					httpclient.executeMethod(post);

					try {
						JSONObject authResponse = new JSONObject(
								new JSONTokener(new InputStreamReader(
										post.getResponseBodyAsStream())));
						// System.out.println("Auth response: "+
						// authResponse.toString(2));

						accessToken = authResponse.getString("access_token");
						instanceUrl = authResponse.getString("instance_url");

						// System.out.println("Got access token: " +
						// accessToken);
					} catch (JSONException e) {
						e.printStackTrace();
						throw new ServletException(e);
					}
				} finally {
					post.releaseConnection();
				}
			}
			// Set a session attribute so that other servlets can get the access
			// token
			request.getSession().setAttribute(ACCESS_TOKEN, accessToken);
			// We also get the instance URL from the OAuth response, so set it
			// in the session too
			request.getSession().setAttribute(INSTANCE_URL, instanceUrl);
		}

		response.sendRedirect(request.getContextPath() + "/DemoRest");
	}

	private void saveOrder(HttpServletRequest request, HttpServletResponse response) throws IOException {
		if ((request.getParameter("Company")).equalsIgnoreCase("BMW_payment")) {
			request.getSession().setAttribute("Tenant_Id__c", "1");
			request.getSession().setAttribute("Customer_Address__c", request.getParameter("address"));
			request.getSession().setAttribute("Promo_Code__c", request.getParameter("Promo_Code"));
			//System.out.println("Selected Payment type"+request.getAttribute("paymentType"));
		} else if ((request.getParameter("Company")).equalsIgnoreCase("Audi")) {
			request.getSession().setAttribute("Tenant_Id__c", "2");
			request.getSession().setAttribute("Customer_Address__c", request.getParameter("address1") + " " + request.getParameter("address2"));
		} else if ((request.getParameter("Company")).equalsIgnoreCase("dodge_buy")) {
			request.getSession().setAttribute("Tenant_Id__c", "3");
			request.getSession().setAttribute("Customer_Address__c", request.getParameter("address"));
		} else if((request.getParameter("Company")).equalsIgnoreCase("Cadillac_payment")){
			request.getSession().setAttribute("Customer_Address__c", request.getParameter("address"));
		} else if((request.getParameter("Company")).equalsIgnoreCase("MB_Payment")){
			request.getSession().setAttribute("Promo_Code__c", request.getParameter("Promo_Code"));
		}
		
		request.getSession().setAttribute("Customer_Name__c", request.getParameter("name"));
		request.getSession().setAttribute("Customer_Ph_Number__c", request.getParameter("phNo"));
		request.getSession().setAttribute("Customer_Email__c", request.getParameter("emailId"));
		if(request.getParameter("cardDetails")!=null && !"".equals(request.getParameter("cardDetails"))){
			request.getSession().setAttribute("Cust_Credit_Debit_Number__c", request.getParameter("cardDetails"));
		}
		request.getSession().setAttribute("Cust_Bank_Acc_No__c", request.getParameter("bankAccNo"));

		/*
		//JSONObject createJson = null;
		if ((request.getParameter("Company")).equalsIgnoreCase("BMW")) {
			//createJson = new JSONObject();
			JSONObject createJson = new JSONObject(request.getParameterMap());
			// save the model info to json
			//createJson.put("TestValue", "test-BMW-models");
			request.getSession().setAttribute("bmwModelJson", createJson);
		} else if ((request.getParameter("Company")).equalsIgnoreCase("BMW_payment")) {
			JSONObject createJson = new JSONObject(request.getParameterMap());
			// save the model info to json
			//createJson.put("bmwPayment", "test-BMW-Payment");
			request.getSession().setAttribute("bmwPaymentJson", createJson);
			// response.sendRedirect("Thankyou.html");
		} else if ((request.getParameter("Company")).equalsIgnoreCase("Audi")) {
			//add the retrieved values from the user to the session
			addValuesToSession(request);
		}
		*/
	}

}
